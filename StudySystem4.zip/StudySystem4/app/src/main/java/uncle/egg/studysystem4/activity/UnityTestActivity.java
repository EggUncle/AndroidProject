package uncle.egg.studysystem4.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import uncle.egg.studysystem4.R;

public class UnityTestActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unity_test);

        setTitle("练习");
    }
}
